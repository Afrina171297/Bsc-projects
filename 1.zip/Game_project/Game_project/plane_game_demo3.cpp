# include "iGraphics.h"

int mposx, mposy;

int screen_size_x=400, screen_size_y=600;

int p_num, e1_num;


class Player{
public: double p_x, p_y;

public: void initialization(double x, double y){
			p_x=x;
			p_y=y;
		}
public: void design(){
			iSetColor(240,230,200);
			iFilledRectangle(p_x, p_y, 20, 20);
		}
public: void move(double x, double y){
			p_x+=x;
			p_y+=y;
		}

}p[2];


class Enemy1{
public: double p_x, p_y, dx, dy;
public: void initialization(double x, double y, double nx, double ny){
			p_x=x;
			p_y=y;
			dx=nx;
			dy=ny;
		}
public: void design(){
			iSetColor(240,230,200);
			iFilledRectangle(p_x, p_y, 20, 20);
		}
public: void move(){
			p_x+=dx;
			p_y+=dy;
			if(p_x+20 > screen_size_x || p_x < 0)dx = -dx;
			if(p_y+20 > screen_size_y || p_y < 0)dy = -dy;
		}
}e1[5];


class bullet{
public: double bul_x[100], bul_y[100];
public: boolean space_pressed;
public: int i, k;
public: void initialization(){
			i=0;
			k=-1;
		}
public: void bullet_design(){
			int j;
			for(j=0; j<i; j++){
				iFilledCircle(bul_x[j], bul_y[j], 3);
			}
		}
public: void bullet_move(int dir){
			int j;
			for(j=0; j<i; j++){
				bul_y[j]+=(dir*10);
				if(bul_y[j]>screen_size_y || bul_y[j]<0){
					k=j;
				}
			}
		}
public: void bullet_button(double x, double y){
			int j;
			if(i<20){
				if(k!=-1){
					bul_y[k]=y;
					bul_x[k]= x;
					k=-1;
				}else{
					bul_y[i]=y;
					bul_x[i]= x;
					i++;
				}
				if(i>=15){
					i=0;
				}
			}
		}
}b[7];



void loop10(){

	int j;
	for(j=0; j<p_num; j++){
		b[j].bullet_move(1);
	}

	for(j=0; j<e1_num; j++){
		b[j+p_num].bullet_move(-1);
	}
}

void loop100(){

	int j;
	for(j=0; j<e1_num; j++){
		e1[j].move();
	}
}

void loop1000(){
	int j;
	for(j=p_num; j<p_num+e1_num; j++){
		b[j].bullet_button(e1[j-p_num].p_x, e1[j-p_num].p_y);
	}
}



void iDraw()
{
	iClear();

	int j;
	for(j=0; j<p_num; j++){
		p[j].design();
		b[j].bullet_design();
	}
	
	for(j=0; j<e1_num; j++){
		e1[j].design();
		b[j+p_num].bullet_design();
	}
	
}

void iMouseMove(int mx, int my)
{

}

void iPassiveMouseMove(int mx, int my)
{
	mposx = mx;
	mposy = my;
}


void iMouse(int button, int state, int mx, int my)
{
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		
	}
	if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		
	}
}

void iKeyboard(unsigned char key)
{
	if(key == 'x')
	{
		exit(0);
	}
	if(key == ' ')
	{
		b[0].bullet_button(p[0].p_x, p[0].p_y);	
	}
}


void iSpecialKeyboard(unsigned char key)
{

	if(key == GLUT_KEY_END)
	{
		exit(0);	
	}
	if(key == GLUT_KEY_LEFT)
	{
		p[0].move(-10, 0);
	}
	if(key == GLUT_KEY_RIGHT)
	{
		p[0].move(10, 0);
	}
	if(key == GLUT_KEY_UP)
	{
		p[0].move(0, 10);
	}
	if(key == GLUT_KEY_DOWN)
	{
		p[0].move(0, -10);
	}
}

int main()
{
	p_num=1;
	e1_num=5;

	int j;
	for(j=0; j<(p_num+e1_num); j++){
		b[j].initialization();
	}

	p[0].initialization(screen_size_x/3, 10);

	e1[0].initialization(0, 300, 10, 7);
	e1[1].initialization(50, 0, 10, 3);
	e1[2].initialization(80, 0, 12, 7);
	e1[3].initialization(150, 0, 15, 17);
	e1[4].initialization(150, 500, 5, 17);

	iSetTimer(10, loop10);
	iSetTimer(100, loop100);
	iSetTimer(1000, loop1000);
	iInitialize(screen_size_x, screen_size_y, "PictureDemo");
	return 0;
}	