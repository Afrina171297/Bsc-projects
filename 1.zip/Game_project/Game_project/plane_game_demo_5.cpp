
# include "iGraphics.h"
# include <algorithm>
#include <String>

int mposx, mposy;

int screen_size_x = 1280, screen_size_y = 720;

int p_num, e1_num, timing=0 ;
int y = 0;



class StageDesign{
public: 
	int startFirstScreen;
	void initialization(){
		startFirstScreen = 1;
	}
	void design(){
		//Showing First Screen for Aproximately 3 sec
		if (timing<=20 && startFirstScreen==1){
			iShowBMP2(0, 0, "screen1_1.bmp", -1);
		}
		else{

		}
		//printf("%d\n", timing);
}
}stg;

class AirCraft{
public: double x, y, bul_x[100], bul_y[100];
		int troop;
		int i, bullet_pressed[20], gun, direction_x, direction_y, player_life_check;

public: void initialization(double x, double y, int troop, int gun){
			this->x = x;
			this->y = y;
			this->troop = troop;
			//printf("%s\n",troop);
			i = 0;
			this->gun = gun;
			direction_x = 1;
			direction_y = 1;
			player_life_check = 1;
			//std::fill_n(bullet_pressed, 20, 0);
			
}
public: void design(){
			if (player_life_check == 1){
				//The design of player
				if (troop == 1){
					iSetColor(50, 205, 50);
				}
				if (troop == 2){
					iSetColor(250, 25, 50);
				}
				iFilledRectangle(x, y, 20, 20);

				//The design of bullet
				int j;
				for (j = 0; j<20; j++){
					if (bullet_pressed[j] = 1){
						iFilledCircle(bul_x[j], bul_y[j], 3);
					}
				}
			}
}
public: void move(double dx, double dy){
			this->x += direction_x*dx;
			this->y += direction_y*dy;
			if (troop == 2){
				if (x + 20 > screen_size_x || x < 0)direction_x = -direction_x;
				if (y + 20 > screen_size_y || y < 0)direction_y = -direction_y;
			}
}


public: void player_alive(AirCraft temp){

			//printf("%d  %d\n", temp->troop, this->troop);
			if (this->troop != temp.troop){
				int j;
				double way;
				if (troop == 1){
					way = -1;
				}
				if (troop == 2){
					way = 1;
				}
				//printf("%d Dead %d!!!!\n", temp.troop, this->troop);
				for (j = 0; j < 20; j++){
					//printf("Dead!!!!");
					if (temp.bul_x[j] > this->x && temp.bul_x[j] < (this->x+20) && temp.bul_y[j] >= way*this->y){
						player_life_check = 0;
						//printf("Dead!!!!");
					}
				}
			}
}

public: void bullet_move(){
			int j, dir;
			if (troop == 1){
				dir = 1;
			}
			if (troop == 2){
				dir = -1;
			}
			for (j = 0; j<20; j++){
				if (bullet_pressed[j] = 1){
					bul_y[j] += (dir * 10);
					if (bul_y[j]>screen_size_y || bul_y[j]<0){
						bullet_pressed[j] = 0;
					}
				}

			}
}

public: void bullet_button(){

			bul_y[i] = y;
			bul_x[i] = x;
			bullet_pressed[i] = 1;
			i++;
			if (i >= 15){
				i = 0;
			}
}
}a[8];

void loop1(){
	timing++;
	printf("%d\n", timing);
}

void loop10(){

	int j;
	for (j = 0; j<p_num+e1_num; j++){
		a[j].bullet_move();
	}
	
}

void loop100(){

	int j;
	for (j = 0; j<e1_num; j++){
		a[j+p_num].move(10, 7);
	}
}

void loop1000(){
	int j;
	for (j = 0; j< e1_num; j++){
		a[j+p_num].bullet_button();
	}
}



void iDraw()
{
	iClear();

	iShowBMP(0, 0, "game_background.bmp");

	int i,j;
	for (j = 0; j<p_num+e1_num; j++){
		a[j].design();
	}
	for (i = 0; i < p_num + e1_num; i++){
		for (j = 0; j<p_num + e1_num; j++){
			a[i].player_alive(a[j]);
		}
	}
	
	stg.design();

	iShowBMP2(0,0, "menuPage1_1.bmp", -1);
}

void iMouseMove(int mx, int my)
{

}

void iPassiveMouseMove(int mx, int my)
{
	mposx = mx;
	mposy = my;
}


void iMouse(int button, int state, int mx, int my)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{

	}
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{

	}
}

void iKeyboard(unsigned char key)
{
	if (key == 'x')
	{
		exit(0);
	}
	if (key == ' ')
	{
		a[0].bullet_button();
		stg.startFirstScreen = 0;
	}
	if (key == 'v')
	{
		a[0].player_life_check = 1;
	}
}


void iSpecialKeyboard(unsigned char key)
{

	if (key == GLUT_KEY_END)
	{
		exit(0);
	}
	if (key == GLUT_KEY_LEFT)
	{
		a[0].move(-10, 0);
	}
	if (key == GLUT_KEY_RIGHT)
	{
		a[0].move(10, 0);
	}
	if (key == GLUT_KEY_UP)
	{
		y++;
		a[0].move(0, 10);
	}
	if (key == GLUT_KEY_DOWN)
	{
		y--;
		a[0].move(0, -10);
	}
}



int main()
{
	p_num = 1;
	e1_num = 5;

	stg.initialization();

	//GetDesktopResolution(screen_size_x, screen_size_y);
	//printf("%d , %d", screen_size_x, screen_size_y);
	
	a[0].initialization(screen_size_x / 3, 10, 1, 1);
	a[1].initialization(50, 0, 2, 1);
	a[2].initialization(80, 0, 2, 1);
	a[3].initialization(150, 0, 2, 1);
	a[4].initialization(150, 500, 2, 1);
	a[5].initialization(0, 300, 2, 1);

	iSetTimer(1, loop1);
	iSetTimer(10, loop10);
	iSetTimer(100, loop100);
	iSetTimer(1000, loop1000);
	
	iInitialize(screen_size_x, screen_size_y, "PictureDemo");
	return 0;
}