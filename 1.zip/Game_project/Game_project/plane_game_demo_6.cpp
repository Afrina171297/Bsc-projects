
# include "iGraphics.h"
# include <algorithm>
#include <stdlib.h>
#include <String.h>

int mposx, mposy;

int screen_size_x2 = 1130, screen_size_y = 720, screen_size_x1=150;

int p_num, e1_num, timing = 0, start_game_timing=25;
int x=0, button_pos_y = 0, menu_button_selected= -1, start_game;
char *num[10] = { "num0.bmp", "num1.bmp", "num2.bmp", "num3.bmp", "num4.bmp", "num5.bmp", "num6.bmp", "num7.bmp", "num8.bmp", "num9.bmp" };
char *word[10][10] = { { "RwordF.bmp", "RwordR.bmp", "RwordE.bmp", "RwordE.bmp", "RwordD.bmp", "RwordO.bmp", "RwordM.bmp" }
						, { "wordR.bmp", "wordE.bmp", "wordS.bmp", "wordP.bmp", "wordE.bmp", "wordC.bmp", "wordT.bmp" }
						, { "wordP.bmp", "wordR.bmp", "wordI.bmp", "wordD.bmp", "wordE.bmp" }
						, { "wordH.bmp", "wordO.bmp", "wordN.bmp", "wordO.bmp", "wordR.bmp" }
						, { "wordS.bmp", "wordA.bmp", "wordC.bmp", "wordR.bmp", "wordI.bmp", "wordF.bmp", "wordI.bmp", "wordC.bmp", "wordE.bmp" } };

char *bbutton[10] = { "Bstart.bmp", "Bscore.bmp", "Binfo.bmp", "Bquit.bmp" };
char *sbutton[10] = { "Sstart.bmp", "Sscore.bmp", "Sinfo.bmp", "Squit.bmp" };

class StageDesign{
public:
	int startFirstScreen, menuScreen, i[5], j, k;
	void initialization(){
		startFirstScreen = 1;
		menuScreen = 0;
		std::fill_n(i, 5, 0);
		k = 0;
	}
	void design(){
		//Showing First Screen for Aproximately 3 sec
		if (timing > 350 && startFirstScreen==1){
			startFirstScreen = 0;
			menuScreen = 1;
		}
		if (startFirstScreen == 1){
			//showing the word 'Freedom'
			for (j = 0; j < i[0]; j++){
				iShowBMP2(350 + j * 70, 350, word[0][j], 8421504);
			}
			if (timing % 20 == 0 && i[0]<7 && i[4] >= 9){
				i[0]++;
			}
			//showing the word 'Respect'
			for (j = 0; j < i[1]; j++){
				iShowBMP2(350 + j * 70, 100, word[1][j], 8421504);
			}
			if (timing % 20 == 0 && i[1]<7){
				i[1]++;
			}
			//showing the word 'Pride'
			for (j = 0; j < i[2]; j++){
				iShowBMP2(420 + j * 70, 200, word[2][j], 8421504);
			}
			if (timing % 20 == 0 && i[2]<5){
				i[2]++;
			}
			//showing the word 'Honor'
			for (j = 0; j < i[3]; j++){
				iShowBMP2(420 + j * 70, 500, word[3][j], 8421504);
			}
			if (timing % 20 == 0 && i[3]<5){
				i[3]++;
			}
			//showing the word 'Sacrifice'
			for (j = 0; j < i[4]; j++){
				iShowBMP2(280 + j * 70, 600, word[4][j], 8421504);
			}
			if (timing % 20 == 0 && i[4]<9){
				i[4]++;
			}

		}
		if(menuScreen==1){
			/*iShowBMP2(0, 0, "menuPage1_1.bmp", -1);
			double button_x[] = { 700 , 740 , 700 }, button_y[] = { 660 - button_pos_y * 180, 630 - button_pos_y * 180, 600 - button_pos_y * 180 };
			iFilledPolygon(button_x, button_y, 3);	*/

			iShowBMP2(0, 0, "menuPage1_2.bmp", 8421504);
			if (button_pos_y - 1<0){
				iShowBMP2(100, 100, sbutton[3], 8421504);
			}
			else{
				iShowBMP2(100, 100, sbutton[button_pos_y - 1], 8421504);
			}

			iShowBMP2(480, 100, bbutton[button_pos_y], 8421504);

			if (button_pos_y + 1>3){
				iShowBMP2(880, 100, sbutton[0], 8421504);
			}
			else{
				iShowBMP2(880, 100, sbutton[button_pos_y + 1], 8421504);
			}
		}
		if(menu_button_selected == 0){
			iShowBMP(150, 0, "bkgrnd1_1.bmp");
			iShowBMP2(650, 650, num[start_game_timing%10], -1);
			iShowBMP2(590, 650, num[(start_game_timing/10)%10], -1);
		}
		//printf("%d %d\n", x, menu_button_selected);
		game_end();
	}

	void game_end(){
		if (menu_button_selected == 3){
			exit(0);
		}
	}
}stg;

class AirCraft{
public: double x, y, bul_x[100], bul_y[100];
		int troop;
		int i, bullet_pressed[100], gun, direction_x, direction_y, player_life_check;

public: void initialization(double x, double y, int troop, int gun){
			this->x = x;
			this->y = y;
			this->troop = troop;
			//printf("%s\n",troop);
			i = 0;
			this->gun = gun;
			direction_x = 1;
			direction_y = 1;
			if (troop == 1){
				player_life_check = 3;
			}
			if (troop == 2){
				player_life_check = 1;
			}
			//std::fill_n(bullet_pressed, 20, 0);

}
public: void design(){

			int n;
			if (troop == 1){
				for (n = 0; n < player_life_check*40; n += 40){
					iShowBMP2(200 + n, 680, "life1_1.bmp", 0);
				}
			}
			//printf("%d\n", y);
			if (player_life_check != 0){
				//The design of bullet
				int j,m;

				iSetColor(255, 100, 10);
				
				for (j = 0; j<100; j++){
					for (m = 0; m <= 40; m += 40){
						if (bullet_pressed[j] = 1){
							iFilledCircle(bul_x[j]+m, bul_y[j], 3);
						}
					}
				}
				

				//The design of player
				if (troop == 1){
					iShowBMP2(x, y, "plyr1_1.bmp", 0);
				}
				if (troop == 2){
					iShowBMP2(x, y, "enmy1_1.bmp", 0);
				}

				
			}
}
public: void move(double dx, double dy){
			//the moving function of player or enemy
			if (player_life_check != 0){
				//checks if the player is alive
				this->x += direction_x*dx;
				this->y += direction_y*dy;
				//moves in x-axis and y-axis accouring to dx and dy
				if (troop == 2){
					//only for enemy
					if (x + 20 > screen_size_x2 || x < screen_size_x1)direction_x = -direction_x;
					if (y + 20 > screen_size_y || y < 0)direction_y = -direction_y;
					//changes the direction of enemy if it touches the screen
				}
			}	
}


public: void player_alive(AirCraft temp){

			//printf("%d  %d\n", temp->troop, this->troop);
			if (this->troop != temp.troop){
				int j;
				double way;
				if (troop == 1){
					way = -1;
				}
				if (troop == 2){
					way = 1;
				}
				//printf("%d Dead %d!!!!\n", temp.troop, this->troop);
				for (j = 0; j < 100; j++){
					//printf("Dead!!!!");
					if (temp.bul_x[j] > this->x && temp.bul_x[j] < (this->x + 20) && temp.bul_y[j] >= way*this->y){
						if (player_life_check <= 0){
							break;
						}
						player_life_check --;
						
						//printf("Dead!!!!");
					}
				}
			}
}

public: void bullet_move(){
			if (player_life_check != 0){
				//checks if the player is alive
				int j, dir;
				if (troop == 1){
					//the direction of bullet's of player
					dir = 1;
				}
				if (troop == 2){
					//the direction of bullet's of enemy
					dir = -1;
				}
				for (j = 0; j<100; j++){
					//total number of bullet=100
					if (bullet_pressed[j] = 1){
						//if the bullet button is pressed
						bul_y[j] += (dir * 50);
						//bullet's y-axis is incresed 10 in direction
						if (bul_y[j]>screen_size_y || bul_y[j]<0){
							//if bullet's y-axis exceeds screensize
							bullet_pressed[j] = 0;
							//that specific bullet doesn't show
						}
					}

				}
			}	
}

public: void bullet_button(){
			if (player_life_check != 0){
				bul_y[i] = y + 30;
				bul_x[i] = x + 20;
				bullet_pressed[i] = 1;
				i++;
				if (i >= 90){
					i = 0;
				}
			}
}
}a[8];

void loop1(){
	timing++;
	
	//timing increses in every 1 millisecond
	//but background slows iSetTimer

	//printf("%d\n", timing);
	if (timing % 1 == 0){
		//this loop will enter in every 1 millisecond
		if (menu_button_selected == 0){
			//if the first button in the menu screen is pressed

			

			int j;
			for (j = 0; j<p_num + e1_num; j++){
				//moving bullet for every player and enemy
				a[j].bullet_move();
			}
		}
	}
	if (timing % 5 == 0){
		if (menu_button_selected == 0){
			//printf("%d\n", start_game_timing);
			start_game_timing--;

			int j;
			for (j = 0; j<e1_num; j++){
				//a[j + p_num].move(30, 60);
				a[j + p_num].move((rand()%30)+30, (rand()%60)+30);
			}
		}
	}
	if (timing % 20 == 0){
		if (menu_button_selected == 0){
			int j;
			for (j = 0; j< e1_num; j++){
				a[j + p_num].bullet_button();
			}
		}

	}
}


void iDraw()
{
	iClear();


	stg.design();

	//printf("%d\n", a[0].player_life_check);
	if (menu_button_selected == 0){
		//iText(0,0, "Life : ");
		int i, j;
		for (j = 0; j<p_num + e1_num; j++){
			a[j].design();
		}
		for (i = 0; i < p_num + e1_num; i++){
			for (j = 0; j<p_num + e1_num; j++){
				a[i].player_alive(a[j]);
			}
		}
	}
	


}

void iMouseMove(int mx, int my)
{

}

void iPassiveMouseMove(int mx, int my)
{
	mposx = mx;
	mposy = my;
}


void iMouse(int button, int state, int mx, int my)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{

	}
	if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{

	}
}

void iKeyboard(unsigned char key)
{
	if (key == 'x')
	{
		exit(0);
	}
	if (key == ' ')
	{
		int i;
		if (menu_button_selected == 0){
			a[0].bullet_button();
		}
		if (stg.menuScreen == 1){
			menu_button_selected = button_pos_y;
			stg.menuScreen = 0;
		}
		if (stg.startFirstScreen == 1){
			stg.startFirstScreen = 0;
			stg.menuScreen = 1;
		}
	}
	if (key == 'v')
	{
		a[0].player_life_check = 1;
	}
}


void iSpecialKeyboard(unsigned char key)
{

	if (key == GLUT_KEY_END)
	{
		exit(0);
	}
	
	if (key == GLUT_KEY_LEFT)
	{
		button_pos_y--;
		if (button_pos_y < 0){
			button_pos_y = 3;
		}
		x--;
		if (menu_button_selected==0)
		{
			a[0].move(-10, 0);
		}
	}
	if (key == GLUT_KEY_RIGHT)
	{
		button_pos_y++;
		if (button_pos_y > 3){
			button_pos_y = 0;
		}
		if (menu_button_selected == 0)
		{
			a[0].move(10, 0);
		}
		x++;
	}
	if (key == GLUT_KEY_UP)
	{
		
		if (menu_button_selected == 0)
		{
			a[0].move(0, 10);
		}
	}
	if (key == GLUT_KEY_DOWN)
	{
		
		if (menu_button_selected == 0)
		{
			a[0].move(0, -10);
		}
	}
}



int main()
{
	p_num = 1;
	e1_num = 5;

	stg.initialization();

	//GetDesktopResolution(screen_size_x, screen_size_y);
	//printf("%d , %d", screen_size_x, screen_size_y);

	a[0].initialization(screen_size_x1 + 600, 10, 1, 1);
	a[1].initialization(screen_size_x1 + 50, 0, 2, 1);
	a[2].initialization(screen_size_x1 + 80, 0, 2, 1);
	a[3].initialization(screen_size_x1 + 150, 0, 2, 1);
	a[4].initialization(screen_size_x1 + 150, 500, 2, 1);
	a[5].initialization(screen_size_x1 + 0, 300, 2, 1);

	iSetTimer(1, loop1);

	iInitialize(1280, 720, "PictureDemo");
	return 0;
}