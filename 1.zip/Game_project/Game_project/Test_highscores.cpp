#include <stdio.h>
void main(){
	FILE *fp;
	//fp = fopen("newHighScore.txt", "rb");
	fp = fopen("newHighScore.txt", "w");
	fprintf(fp, "hello");
	fclose(fp);
}